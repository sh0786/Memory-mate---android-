MemoryMate – Bhoolne Wala AI Brain (Android-only)

Steps:
1. Create project folder and paste files.
2. Replace 'YOUR_GEMINI_KEY_HERE' in lib/services/ai_service.dart with your real API key.
3. Zip the folder -> Upload to GitHub or import into AI app builder.
4. To run locally: open in Android Studio, run `flutter pub get`, then `flutter run`.

Note: Storing API keys in client code is insecure. Use only for testing.