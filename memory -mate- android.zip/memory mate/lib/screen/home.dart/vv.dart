import 'package:flutter/material.dart';
import 'package:speech_to_text/speech_to_text.dart' as stt;
import 'package:flutter_tts/flutter_tts.dart';
import '../services/ai_service.dart';
import '../services/storage_service.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});
  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  late stt.SpeechToText _speech;
  bool _isListening = false;
  String _lastWords = '';
  final FlutterTts _tts = FlutterTts();
  final AIService _ai = AIService();
  final StorageService _store = StorageService();

  @override
  void initState() {
    super.initState();
    _speech = stt.SpeechToText();
    _initTts();
    _store.init();
  }

  Future<void> _initTts() async {
    await _tts.setLanguage('en-US');
    await _tts.setSpeechRate(0.45);
  }

  Future<void> _startListening() async {
    bool available = await _speech.initialize();
    if (available) {
      setState(() => _isListening = true);
      _speech.listen(onResult: (val) async {
        setState(() => _lastWords = val.recognizedWords);
        if (val.finalResult) {
          await _processSpoken(_lastWords);
          setState(() => _isListening = false);
          _speech.stop();
        }
      });
    } else {
      await _speak('Speech recognition not available on this device.');
    }
  }

  Future<void> _stopListening() async {
    await _speech.stop();
    setState(() => _isListening = false);
  }

  Future<void> _processSpoken(String text) async {
    // send to AI to parse
    final aiResult = await _ai.parseCommand(text);

    if (aiResult.action == AIAction.setReminder) {
      await _store.saveReminder(aiResult.payload);
      await _speak('Reminder set');
    } else if (aiResult.action == AIAction.saveMemory) {
      await _store.saveMemory(aiResult.payload);
      await _speak('Saved');
    } else if (aiResult.action == AIAction.queryMemory) {
      final ans = await _store.queryMemory(aiResult.payload['item']);
      await _speak(ans ?? 'I could not find it');
    } else {
      await _speak('I understood: ${aiResult.rawText}');
    }

    setState(() {});
  }

  Future<void> _speak(String text) async {
    await _tts.speak(text);
  }

  Widget _buildList() {
    final reminders = _store.reminders.reversed.toList();
    final memories = _store.memories.reversed.toList();

    return Expanded(
      child: ListView(
        children: [
          const ListTile(title: Text('Reminders')),
          for (final r in reminders)
            ListTile(
              leading: const Icon(Icons.alarm),
              title: Text(r['text'] ?? ''),
              subtitle: Text(r['time'] ?? ''),
            ),
          const Divider(),
          const ListTile(title: Text('Memories')),
          for (final m in memories)
            ListTile(
              leading: const Icon(Icons.memory),
              title: Text(m['item'] ?? ''),
              subtitle: Text(m['text'] ?? ''),
            ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('MemoryMate')),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
          const Text('Speak: "Remind me to... at 5 PM" or "I placed my wallet on the table"'),
          const SizedBox(height: 12),
          Card(child: Padding(padding: const EdgeInsets.all(12.0), child: Text(_lastWords.isEmpty ? 'Nothing yet' : _lastWords))),
          const SizedBox(height: 12),
          ElevatedButton.icon(
            icon: Icon(_isListening ? Icons.mic : Icons.mic_none),
            label: Text(_isListening ? 'Listening...' : 'Start Listening'),
            onPressed: _isListening ? _stopListening : _startListening,
          ),
          const SizedBox(height: 12),
          const Divider(),
          _buildList(),
        ]),
      ),
    );
  }
}