import 'package:flutter/material.dart';
import 'screens/home.dart';

void main() {
  runApp(const MemoryMateApp());
}

class MemoryMateApp extends StatelessWidget {
  const MemoryMateApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'MemoryMate',
      theme: ThemeData(primarySwatch: Colors.deepPurple),
      home: const HomeScreen(),
    );
  }
}