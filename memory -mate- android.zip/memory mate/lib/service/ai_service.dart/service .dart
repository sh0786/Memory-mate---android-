import 'dart:convert';
import 'package:http/http.dart' as http;

enum AIAction { unknown, setReminder, saveMemory, queryMemory }

class AIResult {
  final AIAction action;
  final Map<String, dynamic> payload;
  final String rawText;
  AIResult({required this.action, required this.payload, required this.rawText});
}

class AIService {
  // Put your Gemini/OpenAI API key here:
  final String apiKey = const String GEMINI_API_KEY = "AIzaSyBd4Pf5pmSAEFSRTBWQczDoPFyMlEnBtAE";

  // NOTE: Replace with the actual Gemini/OpenAI endpoint you use.
  final String endpoint = 'https://api.openai.com/v1/chat/completions';

  Future<AIResult> parseCommand(String text) async {
    // Best: call model to extract structured result (action,time,item). Example request commented.
    /*
    final body = {
      "model": "gpt-4o-mini",
      "messages": [
        {"role":"system","content":"Extract JSON: {action: setReminder|saveMemory|queryMemory|unknown, time: ISO|null, item: string|null}"},
        {"role":"user","content": text}
      ]
    };
    final resp = await http.post(Uri.parse(endpoint),
      headers: {'Content-Type':'application/json','Authorization':'Bearer $apiKey'},
      body: jsonEncode(body));
    if (resp.statusCode == 200) {
      final data = jsonDecode(resp.body);
      // parse content -> then build AIResult accordingly
    }
    */

    // Fallback naive rules:
    final lower = text.toLowerCase();
    if (lower.contains('remind')) {
      // naive: store text and approximate timestamp (use real parser in prod)
      return AIResult(
        action: AIAction.setReminder,
        payload: {'text': text, 'time': DateTime.now().toString()},
        rawText: text,
      );
    }
    if (lower.contains('placed') || lower.contains('i put') || lower.contains('i placed')) {
      return AIResult(
        action: AIAction.saveMemory,
        payload: {'text': text, 'item': _extractItem(text)},
        rawText: text,
      );
    }
    if (lower.startsWith('where') || lower.contains('where is')) {
      return AIResult(
        action: AIAction.queryMemory,
        payload: {'item': _extractItem(text)},
        rawText: text,
      );
    }

    return AIResult(action: AIAction.unknown, payload: {}, rawText: text);
  }

  String _extractItem(String text) {
    final parts = text.split(' ');
    if (parts.length >= 2) return '${parts[parts.length - 2]} ${parts.last}';
    return text;
  }
}