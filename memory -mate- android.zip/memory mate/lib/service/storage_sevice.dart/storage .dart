import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';

class StorageService {
  static const _remKey = 'mm_reminders';
  static const _memKey = 'mm_memories';

  List<Map<String, dynamic>> reminders = [];
  List<Map<String, dynamic>> memories = [];

  SharedPreferences? _prefs;

  Future<void> init() async {
    _prefs ??= await SharedPreferences.getInstance();
    final r = _prefs!.getString(_remKey);
    final m = _prefs!.getString(_memKey);
    reminders = r == null ? [] : List<Map<String,dynamic>>.from(jsonDecode(r));
    memories = m == null ? [] : List<Map<String,dynamic>>.from(jsonDecode(m));
  }

  Future<void> saveReminder(Map<String, dynamic> payload) async {
    reminders.add(payload);
    await _prefs!.setString(_remKey, jsonEncode(reminders));
  }

  Future<void> saveMemory(Map<String, dynamic> payload) async {
    memories.add(payload);
    await _prefs!.setString(_memKey, jsonEncode(memories));
  }

  Future<String?> queryMemory(String? item) async {
    if (item == null) return null;
    for (final m in memories.reversed) {
      if ((m['item'] ?? '').toString().toLowerCase() == item.toLowerCase()) {
        return m['text']?.toString();
      }
    }
    return null;
  }
}